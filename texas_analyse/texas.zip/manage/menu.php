﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>Menu</title>
<link href="css/default.css" rel="stylesheet" type="text/css">
<script src="/js/jquery.js" language="javascript"></script>
<style tyle="text/css">
body {
	margin: 0px;
}
a{
	color:#000;
	text-decoration:none;
}
a:hover {
	color: #ff6600;
	text-decoration: underline;
}
.menuHead{
	line-height: 30px;
	font-size: 14px;
	text-align: center;	
	background-color: #507BAE;	
	font-weight: bold;
	color:white;
	border-bottom:2px #aaaaaa solid;
}

.menuItem{
	padding-left:10px;
	line-height: 30px;
	font-size: 12px;
	text-align: left;
	border-bottom:1px #507BAE solid;
	color:#507BAE;
	cursor:pointer;
}

.subItem{
	padding-left:20px;
	line-height: 25px;
	font-size: 12px;
	text-align: left;
	background-color: #fff;	
	cursor:pointer;
	background:url(../image/arrow-right.png) no-repeat 8px 8px
}
.subItem2{
	padding-left:40px;
	line-height: 25px;
	font-size: 12px;
	text-align: left;
	background-color: #fff;	
}

.menuHead a{color: #fff;}
.menuHead a:hover{text-decoration: none;}
	
</style>
<script language="javascript">
	$(document).ready(function(){
		$(".sty1").hide();	
		$(".subItem2").hide();
		$(".menuItem").click(
			function(){
				var men = $("#"+this.id+"1");
				if(men.is(':visible')){
					$("#"+this.id+"1").slideUp("fast");
				}else{
					$(".subItem").css("background","url(../image/arrow-right.png) no-repeat 8px 8px");
				    $(".sty1").slideUp("slow");
				    $(".subItem2").slideUp("slow");
				    $("#"+this.id+"1").slideDown("fast");
				}
			}
		);
		
		$(".subItem").click(
			function(){
				var men = $("#"+this.id+"1");
				if(men.is(':visible')){
					$(this).css("background","url(../image/arrow-right.png) no-repeat 8px 8px");
					$("div[name="+this.id+"1]").slideUp("fast");
				}else{
					$(this).css("background","url(../image/arrow-down.png) no-repeat 8px 8px");
				//	$(".subItem").slideDown("slow");
					$("div[name="+this.id+"1]").slideDown("fast");
				}
			}
		);
	});
</script>
<style type="text/css">
	 
	table{
		font-size:12px;
	}
	td{height:50px;}
	input{height:25px;}
</style>
</head>
<body>
<div class="menuHead">菜单</div>
<?php

//$data_priv = $_SESSION['data_priv'];

include_once 'checkPriv.php';$access_priv = $_SESSION['access_priv'];$uname = $_SESSION['admin_name']; 
?>
<div style="background-color: #f5f5f5;">
	<?php
	if(substr_count($access_priv,"z")>0||$access_priv == 'all'){
	?>
	 
		<div class="menuItem"  id="per">系统设置</div>
		<div id="per1" class="sty1">		
			<div id="per11" class="subItem">权限管理</div>	
				<div name="per111" id="per111" class="subItem2">·<a href="roleList.php" target="contentFrame">后台权限管理</a></div> 
		</div>
 	<?php
	}
	if(substr_count($access_priv,"y")>0||$access_priv == 'all'){
	?>
	 
		<div class="menuItem"  id="y">个人信息设置</div>
		<div id="y1" class="sty1">		
			<div id="y11" class="subItem">密码管理</div>	
				<div name="y111" id="y111" class="subItem2">·<a href="upda.php" target="contentFrame">修改密码</a></div> 
		</div>
 	<?php
	}
	if(substr_count($access_priv,"a")>0||$access_priv == 'all'){
		if($uname == "zhaoboyu"){
		 
		?>
		<div class="menuItem"  id="a">有乐德州扑克</div>
		<div id="a1" class="sty1">	
			<div id="a14" class="subItem">争霸赛相关</div>
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/truePlayer.php" target="contentFrame">争霸赛真实玩家玩牌轮数</a></div>	
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/bangdan.php" target="contentFrame">争霸赛实时排名榜单</a></div>	
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/history.php" target="contentFrame">争霸赛历史排名榜单</a></div>
				 
					
		</div>
		<?php
		}else{
		?>
		<div class="menuItem"  id="a">有乐德州扑克</div>
		<div id="a1" class="sty1">	
			<div id="a15" class="subItem">基础工具</div>
				<div name="a151" id="a151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/online.php" target="contentFrame">在线列表</a></div>
				<div name="a151" id="a151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/userinfo.php" target="contentFrame">用户的详细信息</a></div> 
				<div name="a151" id="a151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/user.php" target="contentFrame">查询用户的uid</a></div> 
				<div name="a151" id="a151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/vipList.php" target="contentFrame">VIP用户列表</a></div> 
			<div id="a11" class="subItem">公告系统</div>
				<div name="a111" id="a111" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/announce.php" target="contentFrame">公告系统</a></div>
				<div name="a111" id="a111" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/sendmsg.php" target="contentFrame">发送系统消息</a></div>
			<div id="a12" class="subItem">过渡页tips系统</div>
				<div name="a121" id="a121" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/enter.php?file=enter&time=${mapSign.time}&sign=${mapSign.sign}&type=1" target="contentFrame">进牌桌过渡页tips</a></div>
				<div name="a121" id="a121" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/enter.php?file=leave&time=${mapSign.time}&sign=${mapSign.sign}&type=1" target="contentFrame">出牌桌过渡页tips</a></div>
			<div id="a13" class="subItem">微信相关</div>
				<div name="a131" id="a131" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/weixin_user.php" target="contentFrame">绑定游戏ID的微信用户</a></div>
				<div name="a131" id="a131" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/weixin_nologin.php" target="contentFrame">未登录游戏的微信玩家</a></div>
			<div id="a14" class="subItem">争霸赛相关</div>
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/truePlayer.php" target="contentFrame">争霸赛真实玩家玩牌轮数</a></div>	
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/bangdan.php" target="contentFrame">争霸赛实时排名榜单</a></div>	
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/history.php" target="contentFrame">争霸赛历史排名榜单</a></div>
				<div name="a141" id="a141" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/addData.php" target="contentFrame">加入人为数据</a></div>
			
			<div id="a16" class="subItem">充值相关</div>
				<div name="a161" id="a161" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/charge.php" target="contentFrame">充值赠送</a></div>
				<div name="a161" id="a161" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/pay.php" target="contentFrame">充值查询</a></div>
				
			<div id="a17" class="subItem">运营数据管理</div>
				<div name="a171" id="a171" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/gmsum.php" target="contentFrame">运营总表</a></div>
				<div name="a171" id="a171" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/gmsum_channel.php" target="contentFrame">渠道列表</a></div>
				<div name="a171" id="a171" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/viewAllAmount.php" target="contentFrame">用户在线数据报表</a></div>
			<div id="a18" class="subItem">系统操作日志</div>
				<div name="a181" id="a181" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/sys_log.php" target="contentFrame">操作日志</a></div>
					
		</div>
		<?php
		}
	 
	}
	if(substr_count($access_priv,"b")>0||$access_priv == 'all'){
	?>	
	
	<div class="menuItem"  id="b">有乐德州扑克(渠道商)</div>
	<div id="b1" class="sty1">	
		<div id="b15" class="subItem">数据查询</div>
			<div name="b151" id="b151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/channel_userinfo.php" target="contentFrame">用户信息</a></div>
			<div name="b151" id="b151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/channelLog.php" target="contentFrame">充值记录</a></div>
			<?php
			if($uname == "kevin.zhu")
			echo '<div name="b151" id="b151" class="subItem2">·<a href="http://op.youjoy.tv/TV_mobile2/gmsum_channel.php" target="contentFrame">渠道列表</a></div>';
			?>
	</div>
	 
	<?php
	}
	if(substr_count($access_priv,"c")>0||$access_priv == 'all'){
	?>	
	
	<div class="menuItem"  id="c">有乐斗地主</div>
	<div id="c1" class="sty1">	
		<div id="c15" class="subItem">基础工具</div>
			<div name="c151" id="c151" class="subItem2">·<a href="http://op.youjoy.tv/lord2/online.php" target="contentFrame">在线列表</a></div>
			<div name="c151" id="c151" class="subItem2">·<a href="http://op.youjoy.tv/lord2/userinfo.php" target="contentFrame">用户的详细信息</a></div> 
			
		<div id="c11" class="subItem">公告系统</div>
			
			<div name="c111" id="c111" class="subItem2">·<a href="http://op.youjoy.tv/lord2/sendmsg.php" target="contentFrame">发送系统消息</a></div>
		
		<div id="c16" class="subItem">充值相关</div>
			<div name="c161" id="c161" class="subItem2">·<a href="http://op.youjoy.tv/lord2/charge.php" target="contentFrame">充值赠送</a></div>
			<div name="c161" id="c161" class="subItem2">·<a href="http://op.youjoy.tv/lord2/pay.php" target="contentFrame">充值查询</a></div>
			
		<div id="c17" class="subItem">运营数据管理</div>
			<div name="c171" id="c171" class="subItem2">·<a href="http://op.youjoy.tv/lord2/gmsum.php" target="contentFrame">运营总表</a></div>
			<div name="c171" id="c171" class="subItem2">·<a href="http://op.youjoy.tv/lord2/gmsum_channel.php" target="contentFrame">渠道列表</a></div>
			<div name="c171" id="c171" class="subItem2">·<a href="http://op.youjoy.tv/lord2/viewAllAmount.php" target="contentFrame">用户在线数据报表</a></div>
			<div name="c171" id="c171" class="subItem2">·<a href="http://op.youjoy.tv/lord2/useronlinetime.php" target="contentFrame">用户在线时长报表</a></div>
		<div id="c18" class="subItem">系统操作日志</div>
			<div name="c181" id="c181" class="subItem2">·<a href="http://op.youjoy.tv/lord2/sys_log.php" target="contentFrame">操作日志</a></div>
 				 
				 
	</div>		 
	<?php
	}
	if(substr_count($access_priv,"d")>0||$access_priv == 'all'){
	?>	
	<div class="menuItem"  id="d">有乐斗地主(渠道商)</div>
	<div id="d1" class="sty1">	
		<div id="d15" class="subItem">数据查询</div>
			<div name="d151" id="d151" class="subItem2">·<a href="http://op.youjoy.tv/lord2/channel_userinfo.php" target="contentFrame">用户信息</a></div>
			<div name="d151" id="d151" class="subItem2">·<a href="http://op.youjoy.tv/lord2/channelLog.php" target="contentFrame">充值记录</a></div>
			 <?php
			if($uname == "kevin.zhu")
			echo '<div name="d151" id="d151" class="subItem2">·<a href="http://op.youjoy.tv/lord2/gmsum_channel.php" target="contentFrame">渠道列表</a></div>';
			?>
				
	</div>		 
			 
	<?php
	}
	?>
	 
	  
</div>

 
<div class="menuHead"><a href="javascript:top.window.location.href='logout.php'">退出</a></div>
</body>
</html>