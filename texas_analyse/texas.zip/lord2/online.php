﻿<?php
require_once '../manage/checkPriv.php';
?>
<script type="text/javascript" src="../js/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css" />
<script>
$(document).ready(function(){
	$("#platformId").val("<?=isset($_GET['tt'])?$_GET['tt']:'all'?>");
});
</script>
 <body>
  	<div class="container">
  
  	<?php
	$player = file_get_contents('http://ddz.protocal.51864.com/log/onlinePlayer.log');
	$obj = json_decode($player);
	$totals = file_get_contents('http://ddz.protocal.51864.com/log/onlineTotals.log');
	$totals = $totals ? json_decode($totals,1) : array();
	?>
	<form method="get">
	<div>
	
		<fieldset>
		<legend>在线列表</legend>	
		<div class="row">
			<input type="hidden" id="time" name="time" value="<?=$_GET['time']?>">
			<input type="hidden" id="sign" name="sign" value="<?=$_GET['sign']?>"> 
			<div span="span1" style="float:right;">
				<input type="submit" value="查&nbsp;&nbsp;询"  class="btn" />
			</div>
			<div class="span2" style="width:700;">
				<select class="span2" id="platformId" name="tt">
					<option value="all">全部</option>
					<option value="table">牌桌</option>
					<option value="room">房间</option>
					<option value="hall">大厅</option>
				</select>&nbsp;&nbsp;的用户
			</div>
		</div>
	</fieldset>
	</div>
	</form>
		<?php if ( $totals ) { ?>
		<div><table class="table table-bordered table-condensed table-hover" style="font-size:12px;">
			<tr class="info" style="font-size:14px;">
				<td>在线总计: <?php echo $totals['在线总计']; ?></td>
				<td>只在房间: <?php echo $totals['只在房间']; ?></td>
				<td>只在大厅: <?php echo $totals['只在大厅']; ?></td>
				<td colspan="2">统计时间: <?php echo $totals['统计时间']; ?></td>
			</tr>
			<tr class="info" style="font-size:14px;">
				<td>房间个数: <?php echo $totals['房间个数']; ?></td>
				<td>牌桌个数: <?php echo $totals['牌桌个数']; ?></td>
				<td>在桌活跃: <?php echo $totals['在桌活跃']; ?></td>
				<td>在桌掉线: <?php echo $totals['在桌掉线']; ?></td>
				<td>在桌假人: <?php echo $totals['在桌假人']; ?></td>
			</tr>
			<?php foreach ( $totals['房间详情'] as $k => $v ) { ?>
			<tr>
				<td>房间编号: <?php echo $v['房间编号']; ?></td>
				<td>牌桌个数: <?php echo $v['牌桌个数']; ?></td>
				<td>在桌活跃: <?php echo $v['在桌活跃']; ?></td>
				<td>在桌掉线: <?php echo $v['在桌掉线']; ?></td>
				<td>在桌假人: <?php echo $v['在桌假人']; ?></td>
			</tr>
			<?php } ?>
		</table></div>
		<?php } ?>
	<div>
		<table class="table table-bordered table-condensed table-hover" style="font-size:12px;">
			<tr class="info">			
				 
				<td width="10%"><strong>房间号</strong></td>
				<td width="10%"><strong>牌桌号</strong></td>
				<td width="10%"><strong>uid</strong></td>
				<td width="10%"><strong>游戏昵称</strong></td>
				<td width="10%"><strong>靓号</strong></td>
				<td width="10%"><strong>性别</strong></td> 
				<td width="10%"><strong>当前筹码</strong></td>  
				<td width="10%"><strong>当前乐币</strong></td>
				<td width="10%"><strong>等级</strong></td> 
				<td width="10%"><strong>exp</strong></td>
				<td width="10%"><strong>win</strong></td>
				<td width="10%"><strong>play</strong></td>
				 
			</tr>
			<tbody id="inRoomUser">
			<?php
			   
			$par = ""; 
			foreach($obj as $val){
				$type = "";$dis = "";
				if($val->roomId){
					if($val->tableId){
						$type = "table";
						 
					}else{
						$type = "room";
						
					}
					 
				}else{
					 
					$type = "hall";
				}
				if(isset($_GET['tt'])){
					if($_GET['tt'] == "table"){
						if($type != "table")$dis="none";
					}elseif($_GET['tt'] == "room"){
						if($type == "hall")$dis="none";
					}elseif($_GET['tt'] == "hall"){
						if($type != "hall")$dis="none";
					}
				}
			?>
				<tr class="table-body" style="display:<?=$dis?>">
					 
					<td><?=$val->roomId?$val->roomId:"";?></td>
					<td><?=$val->tableId?$val->tableId:"";?></td>
					<td><a href="userinfo.php?uid=<?=$val->uid?>"><?=$val->uid?></a></td>
					<td nowrap><?=$val->nick?></td>
					<td><?=$val->cool_num?></td> 
					<td><?=$val->sex==1?"男":"女";?></td>
					<td><?=$val->coins?></td> 
					<td><?=$val->gold?></td>
					<td><?=$val->level?></td>
					
					<td><?=$val->exp?></td>
					<td><?=$val->gameData->win?></td>
					<td><?=$val->gameData->matches?></td>
					  
				</tr>
			<?php
				 
			
			}
			echo '</tbody> ';
			
			 		
			?>
			</tbody>
			<tr>
			<td>总计:</td>
			<td colspan="12"></td>
			</tr>
		</table>
	</div>
	  
	</div>
  </body>
