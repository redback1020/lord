﻿<?php
/**
 * pdo数据库连接类
 * @author  Iris 
 * 
*/
final class DB {
    private $dbhost = null; //服务器地址
    private $dbport = null;//服务器端口号
    private $dbname = null;//服务器连接的用户名
    private $dbuser = null;
    private $dbpass = null;
	private $_db = null;
    
	/**
	 *  构造函数
	 *  @param string $dbpath   程序运行的目录 
	 *  @param object $log  日志
	 * **/
     
	 function __construct(){
	   //var_dump($_SERVER);
		if ( strpos($_SERVER['REQUEST_URI'], 'TV_mobile2') > -1 ) {
			$sysini = "../include/sys_mobile.ini";
		}
		else {
			$sysini = "../include/sys.ini";  //系统的配置文件
		}
		 
	   
		if (file_exists($sysini))
        {
			$sysini_array = parse_ini_file($sysini);
			if(isset($sysini_array['ip'])&&     
				isset($sysini_array['port'])&&
				isset($sysini_array['databasename'])&&
				isset($sysini_array['username'])&&
				isset($sysini_array['password'])
				)
			{
			   $this->dbhost = filter_var($sysini_array['ip'],FILTER_SANITIZE_STRING);
			   $this->dbport = filter_var($sysini_array['port'],FILTER_SANITIZE_NUMBER_INT);
			   $this->dbname = filter_var($sysini_array['databasename'],FILTER_SANITIZE_STRING); 
			   $this->dbuser = filter_var($sysini_array['username'],FILTER_SANITIZE_STRING);
			   $this->dbpass = filter_var($sysini_array['password'],FILTER_SANITIZE_STRING);
			}
			else 
			{
			    echo "读取系统的配置文件有误"; 
				exit();       
			} 
        }
        else
        {
            
            echo "数据库连接的配置文件不存在"; 
            exit("请与管理员联系");
        }			
	}

    /**
     * 返回数据库联接类
     * 
     * @param $dbhost 数据库主机名
     * @param $dbport 数据库端口
     * @param $dbname 数据库名
     * @param $dbuser 数据库用户名
     * @param $dbpass 数据库密码
     * **/
     public function getDB(){
  		try {
		   $this->_db = new PDO("mysql:host=".$this->dbhost.";port= ".$this->dbport.";dbname=".$this->dbname, $this->dbuser , $this->dbpass);
		   $this->_db->exec("SET NAMES 'utf8'");		   
		   
		} catch (PDOException $e) {
			//$this->log->WriteLog("DB","getDB",$e->getMessage()); 
		   echo "Error!: " . $e->getMessage() . "<br/>";
		   die();
		}
		return $this->_db;
    }
    
 
}
$pdo = new DB();
$db = $pdo->getDB();
?>